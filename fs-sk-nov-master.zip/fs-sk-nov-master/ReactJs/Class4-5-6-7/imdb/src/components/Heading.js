const Heading = () => {
    return (
        <h1 className="heading">IMDB Movies</h1>
    )
}

export default Heading;