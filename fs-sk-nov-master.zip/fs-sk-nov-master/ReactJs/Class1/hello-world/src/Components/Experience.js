export const Experience = () => {
    return (
      <div>
        <h2>Companies:</h2>
        <ul>
          <li>Microsoft</li>
          <li>Flipkart</li>
          <li>MoEngage</li>
          <li>Startups</li>
        </ul>
      </div>
    )
  }