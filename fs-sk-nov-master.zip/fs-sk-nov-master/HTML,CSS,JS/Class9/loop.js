var arr = [1, 2, 3, 4];

// for(var i = 0; i < 10; i += 2) {
//   console.log(i);
//   i = 20;
// }

for(var i = 0; i < arr.length; i += 1) {
  console.log(arr[i]);
}


// var j = 0;
// while(j < 10) {
//     console.log(j);
//     j++;
// }

// var j = 0;
// while(j < 10) {
//     console.log(j);
//     j++;
// }

// var k = 11;
// do {
//     console.log(k);
//       k++;
// } 
// while(k < 10)