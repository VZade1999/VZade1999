// Topic 1:

// Falsy Value = 0 null undefined '' false NaN

let a = 12;

if (a) {
    console.log('Truthy Value');
} else {
    console.log('Falsy Value');
}


// Topic 2:

let b = 1;
let c = '1';

console.log(1 == '1');
console.log(1 === '1');


typeof X //

Array.isArray() //
isNaN() // 
