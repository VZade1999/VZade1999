let obj = { name: "Ranjana" };

Object.freeze(obj);