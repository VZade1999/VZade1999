// console.log('Hello ji, khana khake jana!');

/* Line1
 Line2
 Line3 */

 var name = "Akshay";

 console.log(name);

 name = "Tanay";

 console.log(name);

